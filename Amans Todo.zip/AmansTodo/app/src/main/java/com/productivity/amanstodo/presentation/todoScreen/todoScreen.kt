package com.productivity.amanstodo.presentation.todoScreen

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.productivity.amanstodo.data.TodoEntity

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TodoScreen(
	state : TodoScreenState,
	event : (TodoScreenEvent) -> Unit
){

		Column(modifier = Modifier.fillMaxSize(),
			verticalArrangement = Arrangement.spacedBy(10.dp),
			horizontalAlignment = Alignment.CenterHorizontally) {
			Column(modifier = Modifier.fillMaxWidth(),
				verticalArrangement = Arrangement.SpaceEvenly) {

				OutlinedTextField(value = state.todoName,
					onValueChange = {event(TodoScreenEvent.NameChanged(it))})

				OutlinedTextField(value = state.nickName,
					onValueChange = {event(TodoScreenEvent.NickNameChanged(it))})

				OutlinedTextField(value = state.numberOfTimes,
					onValueChange = {event(TodoScreenEvent.NumberOfTimesChanged(it))})

				Button(modifier = Modifier.fillMaxWidth(),
					onClick = {event(TodoScreenEvent.Save)}){
					Text(text = "Save")
				}
			}

			Spacer(modifier = Modifier.height(30.dp))

			LazyColumn(
				verticalArrangement = Arrangement.spacedBy(10.dp),
				contentPadding = PaddingValues(horizontal = 10.dp)
			){
				items(state.listOfTodos){todo->
					TodoCard(todo = todo, event)
				}
			}
		}
}


@Composable
fun TodoCard(todo : TodoEntity,
						 event: (TodoScreenEvent) -> Unit){
	ElevatedCard(modifier = Modifier
		.fillMaxWidth()
		.height(200.dp),
		shape = RoundedCornerShape(20.dp)
	) {
		Column(modifier = Modifier.fillMaxSize(),
			verticalArrangement = Arrangement.SpaceEvenly,
			horizontalAlignment = Alignment.CenterHorizontally){
			Text(text = todo.name,
				modifier = Modifier.fillMaxWidth(),
				textAlign = TextAlign.Start)
			Text(text = todo.nickName,
				modifier = Modifier.fillMaxWidth(),
				textAlign = TextAlign.Start)
			Text(text = "${todo.numberOfTimes}",
				modifier = Modifier.fillMaxWidth(),
				textAlign = TextAlign.Start)
			Text(text = "${todo.id}",
				modifier = Modifier.fillMaxWidth(),
				textAlign = TextAlign.Start)

			Button(onClick = { event(TodoScreenEvent.DeleteATodo(todo)) },
				modifier = Modifier.fillMaxWidth()) {
				Text(text = "Delete")
			}


		}
	}
}