package com.productivity.amanstodo.presentation.todoScreen

import com.productivity.amanstodo.data.TodoEntity

data class TodoScreenState(
	val todoName : String = "",
	val nickName : String = "",
	val numberOfTimes : String = "",
	val id : Int? = null,
	val listOfTodos : List<TodoEntity> = emptyList()
)
