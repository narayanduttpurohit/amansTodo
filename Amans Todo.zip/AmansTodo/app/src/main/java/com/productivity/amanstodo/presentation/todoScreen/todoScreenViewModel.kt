package com.productivity.amanstodo.presentation.todoScreen

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.productivity.amanstodo.data.TodoDaoImpl
import com.productivity.amanstodo.data.TodoEntity
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class TodoScreenViewModel @Inject constructor(
		private val dao : TodoDaoImpl
): ViewModel() {
	init {
		viewModelScope.launch(Dispatchers.IO)
		{
		    delay(300)
			dao.getAllTodos().collect{list->
				_state.update {
					it.copy(listOfTodos = list)
				}
			}
		}
	}
	private val _state = MutableStateFlow(TodoScreenState())
	val state = _state.asStateFlow()

	fun events(e : TodoScreenEvent){
		when(e){
			is TodoScreenEvent.NameChanged -> {
				_state.update {
					it.copy(
						todoName = e.v
					)
				}
			}

			is TodoScreenEvent.NickNameChanged -> {
				_state.update {
					it.copy(
						nickName = e.v
					)
				}
			}

			is TodoScreenEvent.NumberOfTimesChanged -> {
				_state.update {
					it.copy(
						numberOfTimes = e.v
					)
				}
			}

			TodoScreenEvent.Save -> {
				viewModelScope.launch(Dispatchers.IO)
				{
					if(state.value.id == null){
						dao.insertATodo(todo =
						TodoEntity(name = state.value.todoName,
							nickName = state.value.nickName,
							numberOfTimes = if(state.value.numberOfTimes.isEmpty()) 0
								else state.value.numberOfTimes.toInt(),
							id = state.value.id))
					}else{
						TODO("Update the todo with the id")
					}

				}
			}


			is TodoScreenEvent.DeleteATodo -> {
				viewModelScope.launch(Dispatchers.IO)
				{
					dao.deleteATodo(e.v)
				}

			}


			is TodoScreenEvent.IdChanged -> {
				_state.update {
					it.copy(
						id = e.v!!
					)
				}
			}
		}
	}
}