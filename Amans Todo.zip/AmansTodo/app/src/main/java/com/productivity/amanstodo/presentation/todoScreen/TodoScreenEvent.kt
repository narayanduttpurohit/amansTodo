package com.productivity.amanstodo.presentation.todoScreen

import com.productivity.amanstodo.data.TodoEntity

sealed interface TodoScreenEvent{
	data class NameChanged(val v : String) : TodoScreenEvent
	data class NickNameChanged(val v : String) : TodoScreenEvent
	data class NumberOfTimesChanged(val v : String) : TodoScreenEvent
	data class DeleteATodo(val v : TodoEntity) : TodoScreenEvent
	data class IdChanged(val v : Int?) : TodoScreenEvent

	object Save : TodoScreenEvent
}