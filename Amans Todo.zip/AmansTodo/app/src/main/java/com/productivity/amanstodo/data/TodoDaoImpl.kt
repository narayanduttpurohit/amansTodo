package com.productivity.amanstodo.data

import kotlinx.coroutines.flow.Flow
import javax.inject.Inject

class TodoDaoImpl @Inject constructor(
	private val dao : TodoDao
) {

	fun getAllTodos() : Flow<List<TodoEntity>>{
		return dao.getAllTodos()
	}

	suspend fun insertATodo(todo : TodoEntity) {
		dao.insertTodo(todo)
	}

	suspend fun deleteATodo(todo : TodoEntity){
		dao.deleteTodo(todo)
	}

	suspend fun updateTodo(todo: TodoEntity){
		dao.updateTodo(todo)
	}
}