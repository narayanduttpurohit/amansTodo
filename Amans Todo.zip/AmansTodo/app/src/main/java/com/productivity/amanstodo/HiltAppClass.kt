package com.productivity.amanstodo

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class HiltAppClass : Application()