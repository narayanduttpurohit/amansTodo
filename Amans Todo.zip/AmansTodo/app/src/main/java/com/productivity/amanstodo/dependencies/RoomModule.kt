package com.productivity.amanstodo.dependencies

import android.content.Context
import androidx.room.Room
import com.productivity.amanstodo.data.AppDatabaseClass
import com.productivity.amanstodo.data.TodoDao
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@InstallIn(SingletonComponent::class)
@Module
class RoomModule {

	@Provides
	@Singleton
	fun provideDatabase(@ApplicationContext appContext : Context)
	:AppDatabaseClass{
			return Room.databaseBuilder(
				appContext,
				AppDatabaseClass::class.java,
				"AmansTodo"
			).build()
	}

	@Provides
	@Singleton
	fun provideTodoDao(appDataBase : AppDatabaseClass) : TodoDao{
			return appDataBase.todoDao()
	}
}